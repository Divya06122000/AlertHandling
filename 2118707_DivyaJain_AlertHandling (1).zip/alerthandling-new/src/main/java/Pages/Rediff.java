package Pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import Base.Base;

public class Rediff extends Base{
	
public void OpenUrl(){
		
		driver.get("https://www.rediff.com/");
	}
	
	//To search for the details
	public void search() throws InterruptedException{
		
		driver.findElement(By.xpath("//a[text()='Sign in']")).click();
		driver.findElement(By.xpath("//input[@name='proceed']")).click();
		Alert alert = driver.switchTo().alert();
		System.out.println("Alert: " + alert.getText());
		System.out.println("The alert is correct and verified");
		alert.accept();
		driver.findElement(By.xpath("//u[text()='Forgot Password?']")).click();
		driver.findElement(By.xpath("//input[@name='next']")).click();
		Alert alert1 = driver.switchTo().alert();
		System.out.println("Alert: " + alert.getText());
		System.out.println("The alert is correct and verified");
		alert1.accept();
		driver.get("https://www.rediff.com/");
		driver.findElement(By.xpath("//a[text()='Privacy']")).click();
		if (driver.getTitle().contains("Welcome to rediff.com"))
			System.out.println("Page title contains Welcome to rediff.com");
		else
			System.out.println("Page title doesn't contains Welcome to rediff.com");
	}
	
	public static void main(String[] args) throws InterruptedException{
		Rediff ha= new Rediff();
		ha.driverSetup();
		ha.OpenUrl();
		ha.search();
		ha.closeBrowser();
	}
}
